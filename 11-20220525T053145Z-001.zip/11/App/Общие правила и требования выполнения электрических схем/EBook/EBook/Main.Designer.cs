﻿
namespace EBook
{
    partial class Main
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.менюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.теоритическийМатериалToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.встроенныйУчебникToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.учебникВФорматеWordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.официальныйСайтЕСКдToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.практическийМатериалToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.тестыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.тест1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.тест2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.тест3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.тест4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.итоговыйТестToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.печатьОтчетаЛогиныИПаролиПользователейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.печатьОтчетаРезультатыТестовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редакторПользователейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выйтиИзПрограммыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Location = new System.Drawing.Point(12, 31);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(725, 519);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button6.Location = new System.Drawing.Point(23, 170);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(340, 75);
            this.button6.TabIndex = 1;
            this.button6.Text = "Практический материал";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button5.Location = new System.Drawing.Point(23, 68);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(340, 75);
            this.button5.TabIndex = 0;
            this.button5.Text = "Теоритический материал";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Location = new System.Drawing.Point(743, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(305, 519);
            this.panel1.TabIndex = 1;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(153, 296);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(147, 71);
            this.button9.TabIndex = 4;
            this.button9.Text = "Печать отчета";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Visible = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(3, 296);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(147, 71);
            this.button7.TabIndex = 3;
            this.button7.Text = "Редактор пользователей";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Visible = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox2.Controls.Add(this.panel4);
            this.groupBox2.Location = new System.Drawing.Point(3, 87);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(297, 98);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Для новых пользователей";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.button4);
            this.panel4.Controls.Add(this.button3);
            this.panel4.Location = new System.Drawing.Point(6, 21);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(285, 71);
            this.panel4.TabIndex = 1;
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button4.Location = new System.Drawing.Point(148, 14);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(130, 36);
            this.button4.TabIndex = 3;
            this.button4.Text = "Регистрация";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(3, 14);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(136, 36);
            this.button3.TabIndex = 2;
            this.button3.Text = "Обучение";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.button8);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(297, 78);
            this.panel3.TabIndex = 0;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(163, 39);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(126, 32);
            this.button8.TabIndex = 4;
            this.button8.Text = "Выйти";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Visible = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(63, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "Вы не вошли";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox3.Controls.Add(this.panel5);
            this.groupBox3.Location = new System.Drawing.Point(7, 191);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(297, 105);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Для опытных пользователей";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.button1);
            this.panel5.Location = new System.Drawing.Point(6, 21);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(285, 78);
            this.panel5.TabIndex = 1;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(117, 17);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(161, 36);
            this.button2.TabIndex = 1;
            this.button2.Text = "Результаты";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(3, 17);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 36);
            this.button1.TabIndex = 0;
            this.button1.Text = "Войти";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.менюToolStripMenuItem,
            this.отчетToolStripMenuItem,
            this.редакторПользователейToolStripMenuItem,
            this.выйтиИзПрограммыToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1060, 30);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // менюToolStripMenuItem
            // 
            this.менюToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.теоритическийМатериалToolStripMenuItem,
            this.практическийМатериалToolStripMenuItem});
            this.менюToolStripMenuItem.Name = "менюToolStripMenuItem";
            this.менюToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.менюToolStripMenuItem.Text = "Меню";
            // 
            // теоритическийМатериалToolStripMenuItem
            // 
            this.теоритическийМатериалToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.встроенныйУчебникToolStripMenuItem,
            this.учебникВФорматеWordToolStripMenuItem,
            this.официальныйСайтЕСКдToolStripMenuItem});
            this.теоритическийМатериалToolStripMenuItem.Name = "теоритическийМатериалToolStripMenuItem";
            this.теоритическийМатериалToolStripMenuItem.Size = new System.Drawing.Size(269, 26);
            this.теоритическийМатериалToolStripMenuItem.Text = "Теоритический материал";
            // 
            // встроенныйУчебникToolStripMenuItem
            // 
            this.встроенныйУчебникToolStripMenuItem.Name = "встроенныйУчебникToolStripMenuItem";
            this.встроенныйУчебникToolStripMenuItem.Size = new System.Drawing.Size(268, 26);
            this.встроенныйУчебникToolStripMenuItem.Text = "Встроенный учебник";
            this.встроенныйУчебникToolStripMenuItem.Click += new System.EventHandler(this.встроенныйУчебникToolStripMenuItem_Click);
            // 
            // учебникВФорматеWordToolStripMenuItem
            // 
            this.учебникВФорматеWordToolStripMenuItem.Name = "учебникВФорматеWordToolStripMenuItem";
            this.учебникВФорматеWordToolStripMenuItem.Size = new System.Drawing.Size(268, 26);
            this.учебникВФорматеWordToolStripMenuItem.Text = "Учебник в формате Word";
            this.учебникВФорматеWordToolStripMenuItem.Click += new System.EventHandler(this.учебникВФорматеWordToolStripMenuItem_Click);
            // 
            // официальныйСайтЕСКдToolStripMenuItem
            // 
            this.официальныйСайтЕСКдToolStripMenuItem.Name = "официальныйСайтЕСКдToolStripMenuItem";
            this.официальныйСайтЕСКдToolStripMenuItem.Size = new System.Drawing.Size(268, 26);
            this.официальныйСайтЕСКдToolStripMenuItem.Text = "Официальный сайт ЕСКД";
            this.официальныйСайтЕСКдToolStripMenuItem.Click += new System.EventHandler(this.официальныйСайтЕСКдToolStripMenuItem_Click);
            // 
            // практическийМатериалToolStripMenuItem
            // 
            this.практическийМатериалToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.тестыToolStripMenuItem});
            this.практическийМатериалToolStripMenuItem.Name = "практическийМатериалToolStripMenuItem";
            this.практическийМатериалToolStripMenuItem.Size = new System.Drawing.Size(269, 26);
            this.практическийМатериалToolStripMenuItem.Text = "Практический материал";
            // 
            // тестыToolStripMenuItem
            // 
            this.тестыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.тест1ToolStripMenuItem,
            this.тест2ToolStripMenuItem,
            this.тест3ToolStripMenuItem,
            this.тест4ToolStripMenuItem,
            this.итоговыйТестToolStripMenuItem});
            this.тестыToolStripMenuItem.Name = "тестыToolStripMenuItem";
            this.тестыToolStripMenuItem.Size = new System.Drawing.Size(132, 26);
            this.тестыToolStripMenuItem.Text = "Тесты";
            // 
            // тест1ToolStripMenuItem
            // 
            this.тест1ToolStripMenuItem.Name = "тест1ToolStripMenuItem";
            this.тест1ToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.тест1ToolStripMenuItem.Text = "Тест №1";
            this.тест1ToolStripMenuItem.Click += new System.EventHandler(this.тест1ToolStripMenuItem_Click);
            // 
            // тест2ToolStripMenuItem
            // 
            this.тест2ToolStripMenuItem.Name = "тест2ToolStripMenuItem";
            this.тест2ToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.тест2ToolStripMenuItem.Text = "Тест №2";
            this.тест2ToolStripMenuItem.Click += new System.EventHandler(this.тест2ToolStripMenuItem_Click);
            // 
            // тест3ToolStripMenuItem
            // 
            this.тест3ToolStripMenuItem.Name = "тест3ToolStripMenuItem";
            this.тест3ToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.тест3ToolStripMenuItem.Text = "Тест №3";
            this.тест3ToolStripMenuItem.Click += new System.EventHandler(this.тест3ToolStripMenuItem_Click);
            // 
            // тест4ToolStripMenuItem
            // 
            this.тест4ToolStripMenuItem.Name = "тест4ToolStripMenuItem";
            this.тест4ToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.тест4ToolStripMenuItem.Text = "Тест №4";
            this.тест4ToolStripMenuItem.Click += new System.EventHandler(this.тест4ToolStripMenuItem_Click);
            // 
            // итоговыйТестToolStripMenuItem
            // 
            this.итоговыйТестToolStripMenuItem.Name = "итоговыйТестToolStripMenuItem";
            this.итоговыйТестToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.итоговыйТестToolStripMenuItem.Text = "Итоговый тест";
            this.итоговыйТестToolStripMenuItem.Click += new System.EventHandler(this.итоговыйТестToolStripMenuItem_Click);
            // 
            // отчетToolStripMenuItem
            // 
            this.отчетToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.печатьОтчетаЛогиныИПаролиПользователейToolStripMenuItem,
            this.печатьОтчетаРезультатыТестовToolStripMenuItem});
            this.отчетToolStripMenuItem.Name = "отчетToolStripMenuItem";
            this.отчетToolStripMenuItem.Size = new System.Drawing.Size(62, 24);
            this.отчетToolStripMenuItem.Text = "Отчет";
            this.отчетToolStripMenuItem.Visible = false;
            this.отчетToolStripMenuItem.Click += new System.EventHandler(this.отчетToolStripMenuItem_Click);
            // 
            // печатьОтчетаЛогиныИПаролиПользователейToolStripMenuItem
            // 
            this.печатьОтчетаЛогиныИПаролиПользователейToolStripMenuItem.Name = "печатьОтчетаЛогиныИПаролиПользователейToolStripMenuItem";
            this.печатьОтчетаЛогиныИПаролиПользователейToolStripMenuItem.Size = new System.Drawing.Size(448, 26);
            this.печатьОтчетаЛогиныИПаролиПользователейToolStripMenuItem.Text = "Печать отчета \"Логины и пароли - пользователей\"";
            // 
            // печатьОтчетаРезультатыТестовToolStripMenuItem
            // 
            this.печатьОтчетаРезультатыТестовToolStripMenuItem.Name = "печатьОтчетаРезультатыТестовToolStripMenuItem";
            this.печатьОтчетаРезультатыТестовToolStripMenuItem.Size = new System.Drawing.Size(448, 26);
            this.печатьОтчетаРезультатыТестовToolStripMenuItem.Text = "Печать отчета \"Результаты тестов\"";
            // 
            // редакторПользователейToolStripMenuItem
            // 
            this.редакторПользователейToolStripMenuItem.Name = "редакторПользователейToolStripMenuItem";
            this.редакторПользователейToolStripMenuItem.Size = new System.Drawing.Size(195, 24);
            this.редакторПользователейToolStripMenuItem.Text = "Редактор пользователей";
            this.редакторПользователейToolStripMenuItem.Visible = false;
            this.редакторПользователейToolStripMenuItem.Click += new System.EventHandler(this.редакторПользователейToolStripMenuItem_Click);
            // 
            // выйтиИзПрограммыToolStripMenuItem
            // 
            this.выйтиИзПрограммыToolStripMenuItem.Name = "выйтиИзПрограммыToolStripMenuItem";
            this.выйтиИзПрограммыToolStripMenuItem.Size = new System.Drawing.Size(174, 24);
            this.выйтиИзПрограммыToolStripMenuItem.Text = "Выйти из программы";
            this.выйтиИзПрограммыToolStripMenuItem.Click += new System.EventHandler(this.выйтиИзПрограммыToolStripMenuItem_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1060, 562);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Text = "Главное меню";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Main_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        public System.Windows.Forms.Label label2; //изменен на паблик
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem менюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem теоритическийМатериалToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem встроенныйУчебникToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem учебникВФорматеWordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem официальныйСайтЕСКдToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem практическийМатериалToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem тестыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem тест1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem тест2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem тест3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem тест4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem итоговыйТестToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem печатьОтчетаЛогиныИПаролиПользователейToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem печатьОтчетаРезультатыТестовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редакторПользователейToolStripMenuItem;
        public System.Windows.Forms.Button button8; //изменен на паблик
        private System.Windows.Forms.ToolStripMenuItem выйтиИзПрограммыToolStripMenuItem;
        private System.Windows.Forms.Button button9;
    }
}

